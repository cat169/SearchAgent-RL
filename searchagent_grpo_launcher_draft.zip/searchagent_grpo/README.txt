SearchAgent-RL GRPO training launcher (draft, not tested end-to-end)

File:
  training/grpo/train_grpo.sh

Use:
  - Place it in the matching path under /root/SearchAgent-RL (do not overwrite other files).
  - Existing: training/grpo/agent_loop.py, reward.py, and /root/data/grpo/config/search_agent.yaml are reused unchanged.
  - Complete `uv sync` in /root/data/verl first. Ensure `pyserini` is importable from /root/data/verl/.venv/bin/python. Java 21 must be available to Ray workers.
  - The SFT base + special-token LoRA adapter must be merged and verified on the GPU machine into /root/data/models/Qwen3-4B-SFT-Merged (override MODEL_PATH if a different output path).

CPU config-only check (AFTER uv sync):
  cd /root/SearchAgent-RL
  bash training/grpo/train_grpo.sh --check-config > /root/data/grpo/resolved_config.yaml

GPU 1-update smoke (AFTER proper SFT model merge):
  cd /root/SearchAgent-RL
  SMOKE=1 bash training/grpo/train_grpo.sh

Full GRPO run (only after successful smoke):
  cd /root/SearchAgent-RL
  bash training/grpo/train_grpo.sh

Notes:
  - No actual GPU execution / GRPO gradient update has been verified by this draft.
  - `uv sync` does not preserve pip additions not declared in uv.lock. Resolve Pyserini installation before launch, and avoid re-sync after ad-hoc installs.
  - CPU `--check-config` validates Hydra configuration only; it is not a test of Ray rollout/reward/masked gradients.
  - `trainer.save_freq=100` and retention limit 1 minimize checkpoint space; validate available disk before training.
  - 8-prompt x 4-rollout GRPO, max response 6144 tokens; this can be expensive. Check costs after smoke.
